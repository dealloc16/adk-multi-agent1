from google.adk.models import Gemini, LlmResponse
from google.genai import types

class SafeGemini(Gemini):
    """
    A graceful wrapper for the ADK Gemini model.
    Catches 429 RESOURCE_EXHAUSTED errors after tenacity retries fail,
    and returns a predefined fallback response to prevent CLI crashes.
    """
    def __init__(self, fallback_text="**[System]** Quota exhausted. Please try again later.", **kwargs):
        super().__init__(**kwargs)
        self.fallback_text = fallback_text

    async def generate_content_async(self, req, *args, **kwargs):
        try:
            async for chunk in super().generate_content_async(req, *args, **kwargs):
                yield chunk
                
        except Exception as e:
            if "RESOURCE_EXHAUSTED" in str(e) or "429" in str(e):
                print(f"\n[SafeGemini] Intercepted 429 Quota Error.")
                
                # We format the fallback based on whether it appears to be a JSON request
                # This is a basic heuristic. If your schema is rigid, you'll need the exact JSON.
                yield LlmResponse(
                    content=types.Content(
                        role="model", 
                        parts=[types.Part.from_text(text=self.fallback_text)]
                    )
                )
            else:
                raise e
